﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CarRegistration.Models
{
    [Table("cars")]
    public class Car
    {
        [Key]
        public int id { get; set; }

        [MaxLength(40), Required]
        public string brand { get; set; }

        [MaxLength(50), Required]
        public string model { get; set; }

        [MaxLength(30), Required]
        public string color { get; set; }

        [Range(0, int.MaxValue)]
        public int year { get; set; }

        [Range(0.00, Double.MaxValue)]
        public double price { get; set; }

        public string description { get; set; }

        [Column("is_new"), Required]
        public bool isNew { get; set; }

        [Column("date_register"), Required]
        public DateTime dateRegister { get; set; }

        [Column("date_update")]
        public DateTime? dateUpdate { get; set; }

    }
}
