﻿using CarRegistration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarRegistration
{
    public class InitializesDb
    {
        public static void Initialize(ApiContext context)
        {
            context.Database.EnsureCreated();
        }
    }
}
