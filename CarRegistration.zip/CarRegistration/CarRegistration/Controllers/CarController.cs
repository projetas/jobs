﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarRegistration.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CarRegistration.Controllers
{
    [Produces("application/json")]
    [Route("api/Car")]
    public class CarController : Controller
    {
        private readonly ApiContext context;

        public CarController(ApiContext pContext)
        {
            context = pContext;
        }

        // GET: api/Car
        [HttpGet]
        public IEnumerable<Car> Get()
        {
            return context.cars.ToList();
        }

        // GET: api/Car/5
        [HttpGet("{id}", Name = "Get")]
        public IActionResult Get(int id)
        {
            var car = context.cars.FirstOrDefault(p => p.id == id);
            if (car == null)
            {
                return NotFound();
            }

            return new ObjectResult(car);
        }
        
        // POST: api/Car
        [HttpPost]
        public IActionResult Post([FromBody]Car car)
        {
            if (car == null)
            {
                return BadRequest();
            }

            car.dateRegister = DateTime.Now;

            context.cars.Add(car);
            context.SaveChanges();

            return new ObjectResult(car);
        }
        
        // PUT: api/Car/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]Car value)
        {
            if (value == null || value.id != id)
            {
                return BadRequest();
            }

            var car = context.cars.FirstOrDefault(p => p.id == id);
            if (car == null)
            {
                return NotFound();
            }

            car.description = value.description;
            car.brand = value.brand;
            car.model = value.model;
            car.color = value.color;
            car.year = value.year;
            car.price = value.price;
            car.isNew = value.isNew;
            car.dateUpdate = DateTime.Now;
            

            context.cars.Update(car);
            context.SaveChanges();

            return new OkResult();
        }
        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var car = context.cars.FirstOrDefault(t => t.id == id);
            if (car == null)
            {
                return NotFound();
            }

            context.cars.Remove(car);
            context.SaveChanges();

            return new OkResult();
        }
    }
}
